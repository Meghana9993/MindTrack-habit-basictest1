from flask import Flask, render_template, request, redirect, url_for, session, g, flash, jsonify
from flask_mail import Mail, Message
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from datetime import datetime
import requests, os, random

# --- App setup ---
app = Flask(__name__)
app.secret_key = "replace-with-a-random-secret"

# --- Email setup ---
app.config.update(
    MAIL_SERVER='smtp.gmail.com',
    MAIL_PORT=587,
    MAIL_USE_TLS=True,
    MAIL_USERNAME='your_email@gmail.com',   # replace
    MAIL_PASSWORD='your_app_password'       # replace (App Password)
)
mail = Mail(app)

# --- Database path ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "database.db")

# --- DB helpers ---
def get_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = sqlite3.connect(DB_PATH)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS habits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            habit_name TEXT,
            date TEXT,
            done INTEGER DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users (id)
        );
        """)
        db.commit()

def today_str():
    return datetime.now().strftime("%Y-%m-%d")

# ---------------- Routes ----------------
@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return render_template("index.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"].strip()
        password = request.form["password"]
        if not username or not password:
            flash("Username and password required", "error")
            return redirect(url_for("register"))
        db = get_db()
        try:
            db.execute("INSERT INTO users (username, password) VALUES (?, ?)",
                       (username, generate_password_hash(password)))
            db.commit()
            flash("Account created! Please log in.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("Username already exists", "error")
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"].strip()
        password = request.form["password"]
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        if user and check_password_hash(user["password"], password):
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["points"] = 0
            session["badge"] = "🌱 Beginner"
            return redirect(url_for("dashboard"))
        flash("Invalid credentials", "error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/dashboard", methods=["GET", "POST"])
def dashboard():
    if "user_id" not in session:
        return redirect(url_for("login"))

    user_id = session["user_id"]
    db = get_db()

    # Add new habit
    if request.method == "POST":
        habit_name = request.form.get("habit_name", "").strip()
        if habit_name:
            db.execute("INSERT INTO habits (user_id, habit_name, date, done) VALUES (?, ?, ?, 0)",
                       (user_id, habit_name, today_str()))
            db.commit()
            flash("Added habit for today!", "success")
        return redirect(url_for("dashboard"))

    # Fetch today's habits
    rows = db.execute("SELECT * FROM habits WHERE user_id = ? AND date = ?", (user_id, today_str())).fetchall()
    habits = [dict(row) for row in rows]
    total = len(habits)
    done_count = sum(1 for h in habits if h["done"] == 1)
    percent = int((done_count / total) * 100) if total > 0 else 0

    # Gamification
    session["points"] = session.get("points", 0) + done_count * 10
    if session["points"] >= 1000:
        session["badge"] = "🏆 Gold Achiever"
    elif session["points"] >= 500:
        session["badge"] = "🥈 Silver Performer"
    elif session["points"] >= 200:
        session["badge"] = "🥉 Bronze Starter"
    else:
        session["badge"] = "🌱 Beginner"

    # Quote
    try:
        r = requests.get("https://api.quotable.io/random", timeout=3)
        quote = r.json()
        quote_text = quote.get("content")
        quote_author = quote.get("author")
    except:
        quote_text = "Keep going — small steps every day!"
        quote_author = ""

    return render_template("dashboard.html",
                           habits=habits, total=total, done_count=done_count,
                           percent=percent, quote_text=quote_text, quote_author=quote_author)

@app.route("/toggle/<int:habit_id>")
def toggle(habit_id):
    if "user_id" not in session:
        return redirect(url_for("login"))
    user_id = session["user_id"]
    db = get_db()
    row = db.execute("SELECT * FROM habits WHERE id = ? AND user_id = ?", (habit_id, user_id)).fetchone()
    if row:
        new_status = 0 if row["done"] == 1 else 1
        db.execute("UPDATE habits SET done = ? WHERE id = ?", (new_status, habit_id))
        db.commit()
    return redirect(url_for("dashboard"))

# ---- AI Suggestion ----
@app.route("/api/ai_suggestion")
def ai_suggestion_api():
    user_id = session.get("user_id")
    if not user_id:
        return jsonify({"error": "Not logged in"}), 401

    db = get_db()
    habits = db.execute("SELECT habit_name FROM habits WHERE user_id = ?", (user_id,)).fetchall()
    all_habits = [h["habit_name"].lower() for h in habits]

    if any("read" in h for h in all_habits):
        suggestion = random.choice(["Try Journaling ✍️", "Write a short story 📝"])
    elif any("exercise" in h for h in all_habits) or any("run" in h for h in all_habits):
        suggestion = random.choice(["Add Meditation 🧘‍♀️", "Try Yoga 🧘"])
    elif any("meditate" in h for h in all_habits):
        suggestion = random.choice(["Add Gratitude Journal 🙏", "Morning Walk 🌄"])
    else:
        suggestion = random.choice(["Drink more water 💧", "Plan tomorrow 📅", "Read 10 pages 📚"])

    return jsonify({"suggestion": suggestion})

# ---- Calendar (user-specific streaks) ----
@app.route("/api/habit_streaks")
def habit_streaks():
    user_id = session.get("user_id")
    if not user_id:
        return jsonify([])

    db = get_db()
    rows = db.execute("SELECT habit_name, date FROM habits WHERE user_id = ? AND done = 1", (user_id,)).fetchall()
    events = [{"title": row["habit_name"], "start": row["date"]} for row in rows]
    return jsonify(events)

# ---- Email Reminder ----
def send_reminder(email, habit):
    msg = Message(
        subject="⏰ MindTrack Reminder!",
        sender=app.config["MAIL_USERNAME"],
        recipients=[email],
        body=f"Don't forget to complete your habit today: {habit}!"
    )
    mail.send(msg)

# ---- Run ----
if __name__ == "__main__":
    if not os.path.exists(DB_PATH):
        init_db()
    app.run(debug=True)
