-- users table
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL
);

-- habits table: each row is a habit entry for a specific date
CREATE TABLE IF NOT EXISTS habits (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  habit_name TEXT NOT NULL,
  date TEXT NOT NULL,            -- store as 'YYYY-MM-DD'
  done INTEGER DEFAULT 0,        -- 0 or 1
  FOREIGN KEY(user_id) REFERENCES users(id)
);
