document.addEventListener("DOMContentLoaded", function () {
  const calendarEl = document.createElement("div");
  calendarEl.id = "calendar";
  calendarEl.style.marginTop = "30px";
  calendarEl.style.background = "#fff";
  calendarEl.style.borderRadius = "10px";
  calendarEl.style.padding = "15px";
  calendarEl.style.boxShadow = "0 2px 8px rgba(0,0,0,0.1)";
  document.querySelector(".container").appendChild(calendarEl);

  const calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: "dayGridMonth",
    headerToolbar: {
      left: "prev,next today",
      center: "title",
      right: ""
    },
    events: async function (fetchInfo, successCallback, failureCallback) {
      try {
        const res = await fetch("/api/habit_streaks");
        const data = await res.json();
        successCallback(data);
      } catch (err) {
        console.error("Error loading streaks:", err);
        failureCallback(err);
      }
    },
    eventColor: "#4CAF50",
    eventDisplay: "block",
    height: "auto"
  });

  calendar.render();
});
